import { defineConfig } from 'vite'

// base './' keeps image and asset links relative, so the site works on
// GitHub Pages (username.github.io/repo-name/), a custom domain or Lovable.
export default defineConfig({
  base: './',
})
