# PMB Stays Management website

One-page website for PMB Stays holiday let management (Norfolk & East Anglia).

## What's in here

| File | What it is |
| --- | --- |
| `index.html` | The whole site: text, styling and the enquiry form |
| `img/` | The 9 property photos (Derby House, Brefnie Stables, Langwith Mill House) |
| `package.json`, `vite.config.js` | Lets Lovable / Vite run and build the site |
| `.github/workflows/deploy.yml` | Publishes the site to GitHub Pages automatically |

The site works as-is: open `index.html` in a browser and it runs. No build step is needed.

## Put it on GitHub

1. On github.com, click **New repository**, name it e.g. `pmb-stays-management`, and create it.
2. Click **uploading an existing file**, drag in everything from this folder (including the `img` and `.github` folders), and click **Commit changes**.
   - Tip: the `.github` folder is hidden on some computers. If you can't see it, use GitHub Desktop instead, or skip it and use step 3b.
3. Turn the site on:
   - a) **Settings → Pages → Source: GitHub Actions**. The site builds and goes live at `https://<your-username>.github.io/pmb-stays-management/` within a couple of minutes.
   - b) Or, simpler: **Settings → Pages → Source: Deploy from a branch → main → / (root)**. This serves `index.html` directly.
4. To use your own domain (e.g. `manage.pmbstays.co.uk`), add it under **Settings → Pages → Custom domain** and follow GitHub's DNS instructions.

## Put it in Lovable

- **From GitHub:** in Lovable, start a project from your GitHub repository if your plan offers GitHub import, then ask Lovable to keep the design and content.
- **Or by prompt:** start a new Lovable project, upload the photos from `img/`, and paste the contents of `index.html` with a prompt such as: *"Rebuild this page exactly as it is, using these photos."*
- To edit afterwards, just ask Lovable in plain English, e.g. "change the fee to 18%".

## Editing yourself

Everything is in `index.html`. Search for the words you want to change (e.g. `15–20%`) and edit them in any text editor or directly on GitHub (pencil icon).

## Contact details used on the site

- Email: charlotte@pmbstays.co.uk
- WhatsApp: 07538 919632

On the live site, the enquiry form builds a message the owner can send by email or WhatsApp in one tap.
